"""
This is the main module. Some experiments with ci/cd.
"""
__version__ = "0.0.1"
